RAGAV BUILDERS WEBSITE

HOW TO RUN
1. Open a terminal inside this folder.
2. Run: python -m http.server 8000
3. Visit: http://localhost:8000

BACKGROUND
The full-page canvas seeks assets/bgvideo_clean.mp4 according to page scroll position.
It starts on the first frame and progresses to the final frame by the Contact section.
Playback is scroll-controlled rather than autoplay. The video is drawn proportionally
with a dark navy overlay, and the gradient remains as a fallback if video loading fails.

NOTES
- The enquiry form opens the visitor's email client.
- Contact details use the previously supplied RB business card details.
- Portfolio imagery and company achievements should be replaced with verified client
  assets before public launch.
