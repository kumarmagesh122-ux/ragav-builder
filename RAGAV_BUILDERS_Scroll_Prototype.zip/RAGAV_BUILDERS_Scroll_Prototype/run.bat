@echo off
title Ragav Builders Prototype
cd /d "%~dp0"

echo ===================================================
echo   RAGAV BUILDERS - PROTOTYPE LAUNCHER
echo ===================================================

if not exist "%~dp0assets" mkdir "%~dp0assets"

:: Synchronize uploaded official logo
if exist "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793705488943_ba74624f.jpg" (
    copy /y "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793705488943_ba74624f.jpg" "%~dp0assets\ragav-builders-logo.jpg" >nul 2>nul
    copy /y "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793705488943_ba74624f.jpg" "%~dp0assets\ragav-builders-logo.png" >nul 2>nul
    copy /y "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793705488943_ba74624f.jpg" "%~dp0assets\ragav-builders-official-card.jpg" >nul 2>nul
    copy /y "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793705488943_ba74624f.jpg" "%~dp0assets\logo.jpg" >nul 2>nul
) else if exist "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793701568454_41b8f1b2.jpg" (
    copy /y "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793701568454_41b8f1b2.jpg" "%~dp0assets\ragav-builders-logo.jpg" >nul 2>nul
    copy /y "C:\Users\mages\.gemini\antigravity\brain\0542399e-1da1-43ac-819f-3d80acdc46d3\.user_uploaded\media_1793701568454_41b8f1b2.jpg" "%~dp0assets\logo.jpg" >nul 2>nul
)

echo Opening website in your default browser...
start "" "%~dp0index.html"

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo Python server starting on http://localhost:8000
    python -m http.server 8000
    goto end
)

where npx >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo Node server starting on http://localhost:3000
    npx serve -l 3000
    goto end
)

:end
pause
